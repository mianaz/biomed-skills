library(ggplot2)
source("tuner.R")

# Synthetic display examples; the labels do not describe an experiment.
data <- data.frame(group = rep(c("Control", "Treated"), each = 6),
                   value = c(2.5, 3.1, 2.8, 3.4, 2.9, 3.3, 4.2, 4.9, 4.5, 5.2, 4.6, 5.1))
colors <- c(Control = "#A6CEE3", Treated = "#1F78B4")
style <- theme_classic(base_size = 11, base_family = "Arial") +
  theme(axis.text = element_text(size = 10.5, color = "black"),
        axis.title = element_text(size = 11), plot.title = element_text(size = 11.5),
        legend.text = element_text(size = 10.5), legend.title = element_blank(),
        axis.text.x = element_text(angle = 45, hjust = 1), plot.margin = margin(5, 5, 5, 5))
p1 <- ggplot(data, aes(group, value, fill = group)) +
  stat_summary(fun = mean, geom = "col", width = .55, alpha = .35) +
  stat_summary(fun.data = function(x) data.frame(y = mean(x), ymin = mean(x) - sd(x),
                                               ymax = mean(x) + sd(x)),
               geom = "errorbar", width = .18) +
  geom_point(aes(color = group), position = position_jitter(width = .07, seed = 42), size = 1.4) +
  scale_fill_manual(values = colors) + scale_color_manual(values = colors) +
  scale_y_continuous(expand = expansion(mult = c(0, .3))) +
  labs(title = "Response", x = NULL, y = "Relative signal") + style + theme(legend.position = "none")
trajectory <- expand.grid(time = 0:3, group = c("Control", "Treated"))
trajectory$value <- c(1, 1.5, 2.0, 2.4, 1, 2.1, 3.4, 4.7)
p2 <- ggplot(trajectory, aes(time, value, color = group)) + geom_line(linewidth = .5) +
  geom_point(size = 1.5) + scale_color_manual(values = colors) +
  labs(title = "Time course", x = "Time (days)", y = "Relative signal") + style +
  theme(axis.text.x = element_text(angle = 0), legend.position = "inside",
        legend.position.inside = c(.04, .96), legend.justification = c(0, 1),
        legend.key.height = unit(3.4, "mm"), legend.background = element_rect(fill = "white", color = NA))
plots <- list(Response = p1, Trajectory = p2)
stats_data <- list(Response = data)
project <- plot_tuner_export(plots, "plot-tuner", width = 58, height = 58,
                             source_file = "example.R", object_name = "plots", stat_data = stats_data, stat_object = "stats_data")

if (file.exists("plot-tuner/tuner.json")) plot_tuner_render("plot-tuner")
