from pathlib import Path
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from tuner import plot_tuner_export, plot_tuner_render
import json
import shutil

plt.rcParams.update({"font.family": "Arial", "font.size": 11, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.titlesize": 11.5,
                     "xtick.labelsize": 10.5, "ytick.labelsize": 10.5, "legend.fontsize": 10.5})
fig, ax = plt.subplots(figsize=(68 / 25.4, 58 / 25.4))
x = [0, 1, 2, 3]
ax.plot(x, [1, 1.5, 2.0, 2.4], color="#A6CEE3", marker="o", markersize=3, linewidth=1, label="Control")
ax.plot(x, [1, 2.1, 3.4, 4.7], color="#1F78B4", marker="o", markersize=3, linewidth=1, label="Treated")
ax.set(xlabel="Time (days)", ylabel="Relative signal", title="Time course")
ax.legend(loc="upper left", frameon=False, handlelength=1)
fig.subplots_adjust(left=.26, right=.96, bottom=.25, top=.85)
project = plot_tuner_export(fig, "plot-tuner", source_file="example.py", object_name="fig")

if Path("plot-tuner/tuner.json").exists():
    plot_tuner_render("plot-tuner")
